jaccard <-
function(x,y) length(intersect(x,y))/length(union(x,y))
