# Project: OmicsTools
# 
# Author: cesim
###############################################################################


#' Build an microarray expression set
#' 
#' Builds a normalized and background-corrected ExpressionSet object from a set
#' of raw \code{.CEL} files and the the sample metadata.
#' 
#' The function first uses the \code{justRMA} function from \code{affy} package
#' to perform background correction and quantile normalisation. Next, it uses
#' cdf annotation package of the specified cdf to generate the feature table.
#' 
#' @param phenoData An \code{AnnotatedDataFrame} object describing the metadata
#' of the samples. Typically, this is constructed manually or read in from a 
#' table. The sample names (row names of the \code{data} element of the 
#' \code{AnnotatedDataFrame}) should be names \code{.CEL} files, without path
#' location.
#' @param celfilePath The directory where the \code{.CEL} files are located.
#' @param cdfName The name of the package containing the CDF to be used. This
#' package must already be installed but will be automatically loaded. Apart
#' from the CDF package, the accompanying annotation package must be installed
#' as well. For the latter, the following naming convention is used: if the CDF
#' package has the name "\code{foocdf}" then the annotation package is assumed
#' to have name "\code{foo.db}"
#' @return A BioConductor ExpressionSet object with the correct sample and
#' feature annotation.
#' @import Biobase
#' @export 
#' @author Cedric Simillion
buildMicroarraySet <- function(phenoData, celfilePath, cdfName) {
	cdfAnnotationPackage = sub("cdf$", ".db", cdfName)
	require(cdfAnnotationPackage, character.only=TRUE)
	eSet = justRMA(filenames = sampleNames(phenoData), 
			celfile.path=celfilePath, cdfname=cdfName)
	featureTable = select(eval(parse(text=cdfAnnotationPackage)), 
			keys=rownames(exprs(eSet)), keytype="PROBEID",
			columns=c("ENTREZID", "SYMBOL", "GENENAME"))
	rownames(featureTable) <- featureTable$PROBEID
	featureMetaData = data.frame(row.names=colnames(featureTable), description=
					c("The affymetrix probe ID", "The NCBI Entrez Gene ID", 
							"The official HUGO gene symbol", 
							"The official HUGO gene name"))
	featureData = new("AnnotatedDataFrame", data=featureTable, 
			varMetadata=featureMetaData)
	new("ExpressionSet", exprs=exprs(eSet), phenoData=phenoData, 
			featureData = featureData, annotation=cdfAnnotationPackage)
}

#' Build a quantitative proteomics expression set.
#' 
#' Reads in quantitative proteomics data from a single file or a set of files
#' and wraps the data in a Bioconductor ExpressionSet object together with
#' sample metadata and protein feature data.
#' 
#' @section Input files:
#' The input files should be one or more tabular input files with column 
#' headings and without text quoting. The default column separator is the 
#' \code{TAB} character but another one can be specified with the 
#' \code{inputSep} argument. When a single file is given, it is assumed to have
#' one column with Uniprot protein accession numbers and as many columns as
#' there are samples described in the \code{phenoData} with the protein 
#' intensities.
#' 
#' When multiple files are given, each is assumed to contain a column with 
#' Uniprot protein accession numbers and one column with the protein
#' intensities for a single sample. Note that in this case, not all protein
#' identifiers should be present in each input file, the function will simply
#' fill in zero intensities for missing protein groups. Also note that the
#' names of the identifier and intensitiy columns should be the same for all
#' files.
#'
#' @section Protein identifiers and protein groups:
#' Typically, proteomics data files group similar proteins together in protein
#' groups. Therefore, multiple Uniprot accession numbers may be concatenated in
#' the identifier column. The concatenation character can be specified in the 
#' \code{idSep}.
#' 
#' When constructing the expression matrix, the function will expand all
#' proteins in a group so that the matrix contains a single row for each 
#' individual accession number, thereby replicating the intensity values of the
#' original protein group. To obtain a matrix without replicated values, use
#' the \code{contractedMatrix} function provided in this package.
#' 
#' The feature data will map each individual accession number to its original
#' protein group. Note that it is sometimes necessary to strip the accession 
#' numbers as provided in the input files in order to look the protein up in
#' the annotation package. The stripped versions of the accession numbers will
#' be used as row names for the expression matrix and feature data table. The
#' original accession number is however also included in the feature data 
#' table.
#' 
#' @param phenoData An \code{AnnotatedDataFrame} object describing the metadata
#' of the samples. Typically, this is constructed manually or read in from a 
#' table. When reading data from a single file, the sample names (row names of
#' the \code{data} element of the \code{AnnotatedDataFrame}) should be the
#' column names of the data file containing the data of each sample. When
#' reading data from multiple files, the sample names should be the names of
#' the input files, without path location.
#' @param annotationPackage The \code{OrganismDBI} package name to use to 
#' retrieve the annotation of the protein identifiers in the dataset. This
#' package must be installed but will be loaded automatically.
#' @param fileNames One or input data files. When a single file is given, it is
#' assumed to contain data for all samples. When multiple files are given, each
#' is assumed to the data for a single sample. See the Details section for more
#' information about the input files.
#' @param IDColumn The name of the column containing the Uniprot accession 
#' numbers.
#' @param quantColumn The name of the column containing the protein
#' intensities. Ignored in the case of a single input file as the sample names
#' provided in the phenoData must then correspond to the intensity columns.
#' @param transform Boolean specifying whether or not to \eqn{log_2}-transform
#' the protein intensities.
#' @param normalize Boolean specifying whether or not to apply quantile 
#' normalization on the input intensities. When \code{transform} is
#' \code{TRUE}, normalization will be done on the transformed intensities.
#' @param imputeGroupVar When specified, should be the phenoData variable name
#' that groups replicates. For each group of replicates, the function will then
#' impute missing values for those cases were a protein was detected in some
#' but not all of the samples using a normal distribution.
#' @param negInfValue When specified, this value will be used to replace all
#' \code{-Inf} values in the expression matrix. These values occurr when log
#' transformation is applied on 0 values.
#' @param preprocessFunction An optional function that performs preprocessing on
#' the input table(s) to perform e.g. additonal filtering or calculation of
#' intensities. To calculate PMSS scores This function should accept the
#' original input table as a data frame as first argument and the
#' \code{IDColumn} and \code{quantColumn} values passed to this function as
#' second and third arguments. Additional arguments can be specified as well.
#' The \code{preprocessFunction} should always return another dataframe with the
#' same \code{IDColumn} and \code{quantColumn} column names present. The number
#' of rows and the row contents may of course be different.
#' @param idSep The character used to separate multiple accession numbers in
#' the identifier column.
#' @param inputSep The character used to separate columns in the input file(s).
#' @param ... Optional arguments to be passed to \code{preprocessFunction}.
#' @return A BioConductor ExpressionSet object with attached sample and feature
#' annotation. The feature annotation contains the original input accession
#' number and protein group, official accession number and Entrez Gene ID and
#' symbol for each protein in the dataset.
#' @seealso The \code{\link{contractedMatrix}} function to obtain a non-
#' redundant expression matrix. The\code{\link{calculatePMSS}} as an example
#' for \code{preprocessFunction}.
#' @export 
#' @author Cedric Simillion
buildProteomicsSet <- function(phenoData, annotationPackage, fileNames, IDColumn, 
		quantColumn=NULL, transform = TRUE, normalize = TRUE, 
		imputeGroupVar = NULL, negInfValue = NULL, preprocessFunction = NULL, 
		idSep=";", inputSep="\t", ...) {
	IDColumn = make.names(IDColumn)
	quantColumn = make.names(quantColumn)
	require(annotationPackage, character.only=TRUE)
	expMatrix = if (length(fileNames) == 1) 
				matrixFromSingleFile(fileNames, IDColumn, 
						sampleNames(phenoData), inputSep, preprocessFunction) 
			else
				matrixFromMultipleFiles(fileNames, IDColumn, quantColumn, 
						inputSep, preprocessFunction)
	if (transform) {
		expMatrix = log(expMatrix, 2)
	}
	if (normalize) {
		expMatrix = mvQuantileNormalization(expMatrix, 
				if (transform) -Inf else 0)
	}
	if (!is.null(imputeGroupVar)) {
		expMatrix = imputeAllMissing(expMatrix, phenoData, imputeGroupVar, 
				transform)
	}
	if (!is.null(negInfValue)) {
		expMatrix[expMatrix == -Inf] = negInfValue
	}
	featureData = constructFeatureData(expMatrix, annotationPackage, idSep)
	expMatrix = expandMatrix(expMatrix, featureData)
	new("ExpressionSet", exprs=expMatrix, phenoData=phenoData,
			featureData = featureData, annotation=annotationPackage)
}

matrixFromSingleFile <- function(filename, IDColumn, quantColumns, inputSep,
		preprocessFunction, ...) {
	inputTable = read.table(filename, header=TRUE, sep=inputSep, quote="", 
			stringsAsFactors=FALSE, comment.char="")
	if (!is.null(preprocessFunction)) {
		inputTable = preprocessFunction(inputTable, IDColumn, quantColumns, 
				...)
	}
	matrix = as.matrix(inputTable[,quantColumns])
	rownames(matrix) <- inputTable[[IDColumn]]
	matrix[is.na(matrix)] = 0
	matrix
}

matrixFromMultipleFiles <- function(fileNames, IDColumn, quantColumn, inputSep,
		preprocessFunction, ...) {
	inputTables = lapply(fileNames, read.table, header=TRUE, sep=inputSep, 
			quote="", stringsAsFactors=FALSE, comment.char="")
	if (!is.null(preprocessFunction)) {
		inputTables = lapply(inputTables, preprocessFunction, IDColumn, 
				quantColumn, ...)
	}
	allIDs = unique(unlist(lapply(inputTables, function(t) t[[IDColumn]]), 
					use.names=FALSE))
	expMatrix = matrix(0, nrow=length(allIDs), ncol=length(fileNames), 
			dimnames=list(allIDs, basename(fileNames)))
	for (i in 1:length(inputTables)) {
		table = inputTables[[i]]
		expMatrix[table[[IDColumn]],i] = table[[quantColumn]]
	}
	expMatrix
}

constructFeatureData <- function(matrix, annotationPackage, idSep) {
	groupsTable = do.call(rbind, lapply(rownames(matrix), 
					function(i) data.frame(originalAC=strsplit(i, idSep)[[1]],
								proteinGroup=i, stringsAsFactors = FALSE)))
	groupsTable$AC = sub("[_-].*", "", sub("^REV__", "", 
					groupsTable$originalAC))
	groupsTable = groupsTable[!duplicated(groupsTable$AC),]
	annotationTable = select(eval(parse(text=annotationPackage)), 
			keys=groupsTable$AC, keytype="UNIPROT", 
			columns=c("ENTREZID", "SYMBOL", "GENENAME"))
	annotationTable = annotationTable[!duplicated(annotationTable$UNIPROT),]
	annotationTable$UNIPROT = NULL
	featureTable = cbind(groupsTable, annotationTable)
	rownames(featureTable) <- featureTable$AC
	featureLabels = c("The AC as provided in the input file.", 
			"The protein group the entry belongs to.", 
			"The stripped AC used to query the annotation database.",
			"The NCBI Entrez Gene ID", "The official HUGO gene symbol", 
			"The official HUGO gene name")
	featureMetaData = data.frame(row.names=colnames(featureTable), 
			description=featureLabels)
	featureData = new("AnnotatedDataFrame", data=featureTable, 
			varMetadata=featureMetaData)
	featureData
}

expandMatrix <- function(expMatrix, featureData) {
	expMatrix = expMatrix[pData(featureData)$proteinGroup,]
	rownames(expMatrix) <- featureNames(featureData)
	expMatrix
}

#' Construct protein PMSS scores from raw peptide z-scores
#' 
#' Sums all z-scores in a peptide match table to obtain PMSS scores per 
#' protein.
#' 
#' @param inputTable A data frame containing peptide identification results.
#' Each row should correspond to one peptide and should contain a UniProt
#' accession number and a z-score.
#' @param IDColumn The name of the column containing the accession number.
#' @param zColumn The name of the column containing the z-score
#' @return A new data frame with column names \code{IDColumn} and 
#' \code{zColumn} although the latter column will now contain the PMSS scores
#' rather than the original z-scores.
#' @export
calculatePMSS <- function(inputTable, IDColumn, zColumn) {
	outputTable = do.call(rbind, by(inputTable, 
					as.factor(inputTable[[IDColumn]]), function(t) data.frame(
								id=as.character(unique(t[[IDColumn]])), 
								PMSS=sum(t[[zColumn]]), stringsAsFactors=FALSE)
	))
	colnames(outputTable) <- c(IDColumn, zColumn)
	outputTable
}

#' Get a non-redundant protein expression matrix.
#' 
#' Only relevant for proteomics ExpressionSet objects constructed with the 
#' \code{buildProteomicsSet}. As the expressionMatrix of these objects contains
#' rows with repeated values since protein groups are expanded, it is sometimes
#' useful to obtain a non-redundant expression values to perform statistical
#' analyses. This function can be used to obtain this matrix
#' @param expressionSet The proteomics expression set for which to extract the
#' non-redundant expression matrix.
#' @return A matrix containg the non-redundant expression values.
#' @export
contractedMatrix <- function(expressionSet) {
	indices = !duplicated(fData(expressionSet)$proteinGroup)
	exprs(expressionSet)[indices,]
}

imputeAllMissing <- function(expMatrix, phenoData, groupVar, transform) {
	groupNames = unique(as.character(pData(phenoData)[[groupVar]]))
	groupIndices = lapply(groupNames, function(x) 
				which(pData(phenoData)[[groupVar]] == x))
	for (group in groupIndices) {
		if (length(group) <= 1) {
			next
		}
		expMatrix[,group] = imputeGroupMissing(expMatrix[,group], transform)
	}
	return(expMatrix)
}

imputeGroupMissing <- function(replicatesMatrix, transform) {
	n = ncol(replicatesMatrix)
	missValue = if (transform) -Inf else 0
	for (i in 1:(n-1)) {
		indices = apply(replicatesMatrix, 1, 
				function(x) length(which(x == missValue)) == i)
		allValues = replicatesMatrix[indices,]
		definedValues = allValues[allValues > missValue]
		if (length(definedValues) == 1) {
			imputedValues = definedValues
		} else {
			p_x = ((i+1)/(n+1)+n/(n+1))/2
			sigma = sd(definedValues)/(2*(1-p_x))
			x = mean(definedValues)
			mu = x - qnorm(p_x)*sigma
			imputedValues = qnorm((1:i)/(n+1), mu, sigma)
		}
		replicatesMatrix[indices,] = t(apply(rbind(replicatesMatrix[indices,]),
						1, function(r){
							r[r == missValue] = imputedValues
							r
						}))
	}
	replicatesMatrix
}
