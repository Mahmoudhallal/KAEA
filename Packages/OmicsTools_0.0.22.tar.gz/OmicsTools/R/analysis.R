# Project: OmicsTools
# 
# Author: cesim
###############################################################################

#' Get sample groupings of an ExpressionSet object.
#' 
#' @param expressionSet The ExpressionSet object from which to obtain sample
#' groups.
#' @param variables The variables to be included. When not specified, all
#' sample variables in the phenoData element will be included.
#' @import SetTools
#' @author Cedric Simillion
#' @export
getSampleGroups <- function(expressionSet, variables=NULL) {
	sampleData = pData(expressionSet)
	if (is.null(variables)) {
		variables = colnames(sampleData)
	}
	sampleGroups = lapply(variables, function(v) {
				values = as.character(unique(sampleData[[v]]))
				subList = lapply(values, 
						function(x) which(sampleData[[v]] == x))
				names(subList) <- values
				subList
			})
	names(sampleGroups) <- variables
	sampleGroups
}


#' Perform quantile normalization while ignoring missing values
#' 
#' @param inputMatrix Expression matrix on which to perform quantile
#' normalization.
#' @param missingValue The value in the matrix that indicates missing values.
#' Typically -Inf, NA or 0
#' @return A matrix with the same dimensions and dimnames as the input matrix.
#' @export
mvQuantileNormalization <- function(inputMatrix, missingValue) {
	if (!is.na(missingValue)) {
		inputMatrix[inputMatrix == missingValue] = NA
	}
	rankMatrix = apply(inputMatrix, 2, rank, na.last=FALSE)
	sortedMatrix = apply(inputMatrix, 2, sort, na.last=FALSE)
	normValues = apply(sortedMatrix, 1, mean, na.rm=TRUE)
	normValues[is.nan(normValues)] = missingValue
    outputMatrix = matrix(missingValue, nrow=nrow(inputMatrix), 
			ncol=ncol(inputMatrix), dimnames=dimnames(inputMatrix))
	for (c in 1:ncol(inputMatrix)) {
		definedIndices = !is.na(inputMatrix[,c])
		outputMatrix[definedIndices,c] = 
				normValues[rankMatrix[definedIndices,c]]
	}
	outputMatrix
}


#' Get differentially expressed genes between different groups of samples
#' 
#' This function wraps around the \code{\link{limma}} package and takes care of
#' constructiong the design and contrast matrices.
#' @param expressionSet An ExpressionSet object
#' @param groupVar Should be a \code{phenoData} variable name. This variable
#' should assign a unique identifier to each sample group that you wish to
#' compare.
#' @param contrasts A character vector with all the contrasts to be computed.
#' Each contrast is a string containing two group names separated by a minus
#' sign (\code{-}). So, if you have 4 groups labeled \code{group1, group2, 
#' group3, group4}, the contrasts vector can look like \code{c("group1-group2",
#' "group3-group4")}.
#' @param pValueCutoff The maximum allowed adjusted p-value in each topTable
#' @return A list of dataframes. Each dataframe contains the output of the 
#' \code{limma} \code{\link[limma]{topTable}} function. The names in the list
#' correspond to the contrasts specified.
#' @author Cedric Simillion
#' @import limma
#' @export
getTopTables <- function(expressionSet, groupVar, contrasts, pValueCutoff=1) {
	groups = as.factor(pData(expressionSet)[[groupVar]])
	design = model.matrix(~0+groups)
	colnames(design) <- levels(groups)
	contrastMatrix = makeContrasts(contrasts=contrasts, levels=design)
	fit = eBayes(contrasts.fit(lmFit(expressionSet, design), contrastMatrix))
	topTables = lapply(colnames(contrastMatrix), function(x) 
				topTable(fit, coef=x, number=+Inf, p.value=pValueCutoff))
	names(topTables) <- colnames(contrastMatrix)
	return(topTables)

}

#' Perform an F-test across different contrasts.
#' 
#' This function wraps around the \code{limma} \code{\link[limma]{topTableF}}
#' function and takes care of constructiong the design and contrast matrices.
#' 
#' @param expressionSet An ExpressionSet object
#' @param groupVar Should be a \code{phenoData} variable name. This variable
#' should assign a unique identifier to each sample group that you wish to
#' compare.
#' @param contrasts A character vector with all the contrasts to be computed.
#' Each contrast is a string containing two group names separated by a minus
#' sign (\code{-}). So, if you have 4 groups labeled \code{group1, group2, 
#' group3, group4}, the contrasts vector can look like \code{c("group1-group2",
#' "group3-group4")}.
#' @param pValueCutoff The maximum allowed adjusted p-value in the output.
#' @return The output of the \code{\link[limma]{topTableF}} function. 
#' @author Cedric Simillion
#' @export 
getFTopTable <- function(expressionSet, groupVar, contrasts, pValueCutoff=1) {
	groups = as.factor(pData(expressionSet)[[groupVar]])
	design = model.matrix(~0+groups)
	colnames(design) <- levels(groups)
	contrastMatrix = makeContrasts(contrasts=contrasts, levels=design)
	fit = eBayes(contrasts.fit(lmFit(expressionSet, design), contrastMatrix))
	topTableF(fit, number=+Inf, p.value=pValueCutoff)	
}

